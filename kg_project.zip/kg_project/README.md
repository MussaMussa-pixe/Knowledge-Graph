# Knowledge Graph Embedding Project (Link Prediction)

A complete, modular project that builds a **knowledge graph** from the FB15k-237 dataset
and trains **TransE, DistMult and ComplEx** models to predict missing facts
(e.g. `(Pakistan, capital, ?)` -> the model ranks candidate entities).

## 1. Task

> Given a knowledge graph made of triples `(head, relation, tail)`, train a model that
> predicts missing links, and evaluate it with **MRR** and **Hits@1/3/10**.

Real-world uses: recommendation systems, search engines, question answering, fraud detection, drug discovery.

## 2. Dataset

| Item | Value |
|---|---|
| Name | FB15k-237 (subset of Freebase) |
| Entities / Relations | 14,505 / 237 |
| Train / Valid / Test triples | 272,115 / 17,526 / 20,438 |
| Format | tab-separated: `head<TAB>relation<TAB>tail` |

**Download URLs**
- https://raw.githubusercontent.com/villmow/datasets_knowledge_embedding/master/FB15k-237/train.txt
- https://raw.githubusercontent.com/villmow/datasets_knowledge_embedding/master/FB15k-237/valid.txt
- https://raw.githubusercontent.com/villmow/datasets_knowledge_embedding/master/FB15k-237/test.txt

The code downloads these automatically (`python main.py download`).
To use a smaller dataset, set `dataset.name: WN18RR` in `config.yaml` (same repository).

## 3. Project structure

```
kg_project/
├── README.md            # this file
├── requirements.txt     # dependencies
├── config.yaml          # all hyper-parameters and paths
├── main.py              # CLI: download / explore / train / evaluate / predict
├── scripts/
│   └── download_data.py # standalone dataset downloader
├── src/kg/
│   ├── config.py        # load + validate config
│   ├── schema.py        # Triple and Vocabulary (the graph schema)
│   ├── data.py          # download, read triples, filter sets, negative sampling
│   ├── graph.py         # NetworkX graph, statistics, GraphML + Neo4j CSV export
│   ├── models.py        # TransE, DistMult, ComplEx
│   ├── train.py         # training loop, validation, checkpointing
│   ├── evaluate.py      # filtered MRR / Hits@k
│   └── predict.py       # inference for missing head/tail
├── tests/test_basic.py  # unit tests
├── data/                # downloaded dataset (git-ignored)
└── outputs/             # checkpoint, metrics, graph exports (git-ignored)
```

## 4. Schema

- **Triple(head, relation, tail)**: one fact; every field must be a non-empty string.
- **Vocabulary**: maps entity and relation strings to integer ids (built from the *train* split only, so there is no leakage).
- **Node label** in Neo4j: `Entity`; **relationship type**: the Freebase relation path converted to `UPPER_SNAKE_CASE`.

## 5. Models

| Model | Score function | Loss |
|---|---|---|
| TransE | `-‖h + r − t‖` | margin ranking |
| DistMult | `⟨h, r, t⟩` | logistic (softplus) |
| ComplEx | `Re(⟨h, r, conj(t)⟩)` | logistic (softplus) |

Training uses random negative sampling (corrupting head or tail) and the Adam optimizer.
Evaluation is **filtered**: other known true answers are removed before ranking.

## 6. Setup and run

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python main.py download                 # get the dataset
python main.py explore                  # graph statistics + GraphML + Neo4j CSV export
python main.py train --model complex --epochs 50
python main.py evaluate                 # test-set MRR / Hits@k
python main.py predict --head /m/027rn --relation /location/country/form_of_government --top-k 5
python -m pytest -q                     # run tests
```

Quick smoke test on CPU: `python main.py train --model distmult --epochs 2`.

Outputs: `outputs/model.pt` (best checkpoint), `outputs/metrics.json` (loss and validation history),
`outputs/graph.graphml`, `outputs/neo4j/{nodes,relationships}.csv`.

## 7. Expected results

With the default settings, ComplEx typically reaches roughly MRR 0.2 to 0.3 on FB15k-237.
Exact numbers depend on epochs, embedding size and random seed. Increase `epochs`
and `embedding_dim` for better results; a GPU is recommended for 50+ epochs.

## 8. Load the graph into Neo4j (optional)

Copy `outputs/neo4j/nodes.csv` and `relationships.csv` into Neo4j's `import` folder, then:

```cypher
LOAD CSV WITH HEADERS FROM 'file:///nodes.csv' AS row
MERGE (:Entity {id: row.`entityId:ID`});
```
For millions of edges use `neo4j-admin database import full --nodes=nodes.csv --relationships=relationships.csv`.

## 9. Ideas to extend

- Add RotatE or ConvE models in `models.py`.
- Use entity names (Freebase MIDs map to names) for readable predictions.
- Build a small Flask/FastAPI service on top of `predict.py`.
- Add hyper-parameter search over `config.yaml`.

## 10. Note

Dataset: Toutanova and Chen (2015), FB15k-237. Models: Bordes 2013 (TransE), Yang 2015 (DistMult), Trouillon 2016 (ComplEx).
