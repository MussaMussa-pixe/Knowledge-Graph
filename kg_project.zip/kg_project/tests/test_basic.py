import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.kg.data import sample_negatives
from src.kg.graph import build_graph, graph_stats
from src.kg.schema import Triple, Vocabulary


def make_vocab():
    v = Vocabulary()
    for t in [Triple("a", "likes", "b"), Triple("b", "knows", "c")]:
        v.add_triple(t)
    return v


def test_triple_validation():
    with pytest.raises(ValueError):
        Triple("", "r", "t").validate()


def test_vocab_ids():
    v = make_vocab()
    assert v.num_entities == 3 and v.num_relations == 2
    assert v.encode(Triple("a", "likes", "b")) == (0, 0, 1)


def test_negative_sampling_shape():
    batch = np.array([[0, 0, 1], [1, 1, 2]])
    neg = sample_negatives(batch, 3, 5, np.random.default_rng(0))
    assert neg.shape == (2, 5, 3)
    assert (neg[:, :, 1] == batch[:, None, 1]).all()   # relation never corrupted


def test_graph_stats():
    v = make_vocab()
    g = build_graph(np.array([[0, 0, 1], [1, 1, 2]]), v)
    s = graph_stats(g)
    assert s["nodes"] == 3 and s["edges"] == 2


def test_models_scores_consistent():
    torch = pytest.importorskip("torch")
    from src.kg.models import build_model
    cfg = {"embedding_dim": 8, "margin": 1.0, "norm": 1}
    h, r, t = torch.tensor([0, 1]), torch.tensor([0, 1]), torch.tensor([2, 3])
    for name in ("transe", "distmult", "complex"):
        m = build_model(name, 5, 2, cfg).eval()
        direct = m.score(h, r, t)
        via_tails = m.score_tails(h, r).gather(1, t.unsqueeze(1)).squeeze(1)
        via_heads = m.score_heads(r, t).gather(1, h.unsqueeze(1)).squeeze(1)
        assert torch.allclose(direct, via_tails, atol=1e-4), name
        assert torch.allclose(direct, via_heads, atol=1e-4), name
