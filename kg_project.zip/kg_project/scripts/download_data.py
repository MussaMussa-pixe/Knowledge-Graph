"""Standalone dataset downloader: python scripts/download_data.py [FB15k-237|WN18RR]"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.kg.config import load_config, resolve
from src.kg.data import download_dataset

if __name__ == "__main__":
    cfg = load_config()
    d = cfg["dataset"]
    name = sys.argv[1] if len(sys.argv) > 1 else d["name"]
    path = download_dataset(d["base_url"], name, d["files"], resolve(d["data_dir"]))
    print("Saved to", path)
