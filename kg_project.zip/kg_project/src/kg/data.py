"""Dataset download, loading, and negative sampling."""
from pathlib import Path
from typing import Dict, List, Set, Tuple

import numpy as np
import requests

from .schema import Triple, Vocabulary


def download_dataset(base_url: str, name: str, files: List[str], data_dir: Path) -> Path:
    """Download dataset files (train/valid/test) if they do not already exist."""
    target = Path(data_dir) / name
    target.mkdir(parents=True, exist_ok=True)
    for fname in files:
        dest = target / fname
        if dest.exists() and dest.stat().st_size > 0:
            continue
        url = f"{base_url}/{name}/{fname}"
        print(f"Downloading {url}")
        r = requests.get(url, timeout=60)
        r.raise_for_status()
        dest.write_bytes(r.content)
    return target


def read_triples(path: Path) -> List[Triple]:
    triples = []
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip():
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) != 3:
                raise ValueError(f"{path}:{line_no} expected 3 tab-separated columns")
            t = Triple(*parts)
            t.validate()
            triples.append(t)
    return triples


class KGData:
    """Holds vocabulary and integer triples for train/valid/test splits."""

    def __init__(self, dataset_dir: Path):
        dataset_dir = Path(dataset_dir)
        raw = {s: read_triples(dataset_dir / f"{s}.txt") for s in ("train", "valid", "test")}
        self.vocab = Vocabulary()
        for t in raw["train"]:           # vocabulary built from train only
            self.vocab.add_triple(t)
        self.splits: Dict[str, np.ndarray] = {}
        for s, triples in raw.items():
            enc = [self.vocab.encode(t) for t in triples
                   if t.head in self.vocab.entity2id and t.tail in self.vocab.entity2id
                   and t.relation in self.vocab.relation2id]
            self.splits[s] = np.array(enc, dtype=np.int64).reshape(-1, 3)
        # Filter set: every known true triple (used in "filtered" evaluation)
        self.all_true: Set[Tuple[int, int, int]] = set()
        for arr in self.splits.values():
            self.all_true.update(map(tuple, arr.tolist()))

    def summary(self) -> Dict[str, int]:
        return {
            "entities": self.vocab.num_entities,
            "relations": self.vocab.num_relations,
            **{f"{k}_triples": len(v) for k, v in self.splits.items()},
        }


def sample_negatives(batch: np.ndarray, num_entities: int, k: int,
                     rng: np.random.Generator) -> np.ndarray:
    """Corrupt head or tail (50/50) with random entities. Returns (B, k, 3)."""
    B = len(batch)
    neg = np.repeat(batch[:, None, :], k, axis=1).copy()
    corrupt_head = rng.random((B, k)) < 0.5
    rand_ent = rng.integers(0, num_entities, size=(B, k))
    neg[:, :, 0] = np.where(corrupt_head, rand_ent, neg[:, :, 0])
    neg[:, :, 2] = np.where(~corrupt_head, rand_ent, neg[:, :, 2])
    return neg
