"""Knowledge graph package: data, schema, graph, models, training, evaluation."""
__version__ = "1.0.0"
