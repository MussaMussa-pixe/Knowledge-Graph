"""Inference: predict missing tails / heads for a query."""
from typing import List, Tuple

import torch


@torch.no_grad()
def predict_tails(model, ckpt, head: str, relation: str, top_k: int = 10,
                  filter_known=None, device="cpu") -> List[Tuple[str, float]]:
    """Answer (head, relation, ?) with the top-k most plausible entities."""
    e2i, r2i = ckpt["entity2id"], ckpt["relation2id"]
    if head not in e2i:
        raise KeyError(f"Unknown entity: {head}")
    if relation not in r2i:
        raise KeyError(f"Unknown relation: {relation}")
    id2e = {v: k for k, v in e2i.items()}
    h = torch.tensor([e2i[head]], device=device)
    r = torch.tensor([r2i[relation]], device=device)
    scores = model.score_tails(h, r)[0]
    if filter_known:
        for t in filter_known:
            scores[t] = float("-inf")
    vals, idx = torch.topk(scores, top_k)
    return [(id2e[i], v) for i, v in zip(idx.tolist(), vals.tolist())]


@torch.no_grad()
def predict_heads(model, ckpt, relation: str, tail: str, top_k: int = 10,
                  device="cpu") -> List[Tuple[str, float]]:
    """Answer (?, relation, tail)."""
    e2i, r2i = ckpt["entity2id"], ckpt["relation2id"]
    id2e = {v: k for k, v in e2i.items()}
    r = torch.tensor([r2i[relation]], device=device)
    t = torch.tensor([e2i[tail]], device=device)
    vals, idx = torch.topk(model.score_heads(r, t)[0], top_k)
    return [(id2e[i], v) for i, v in zip(idx.tolist(), vals.tolist())]
