"""Load and validate the YAML configuration."""
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]


def load_config(path: str | Path = ROOT / "config.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    for section in ("dataset", "model", "training", "evaluation", "paths"):
        if section not in cfg:
            raise KeyError(f"Missing config section: {section}")
    if cfg["model"]["name"].lower() not in ("transe", "distmult", "complex"):
        raise ValueError("model.name must be transe, distmult or complex")
    return cfg


def resolve(cfg_path: str) -> Path:
    """Resolve a path from config relative to the project root."""
    p = Path(cfg_path)
    return p if p.is_absolute() else ROOT / p
