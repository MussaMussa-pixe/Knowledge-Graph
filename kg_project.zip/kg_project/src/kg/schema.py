"""Schema definitions for the knowledge graph.

A knowledge graph is a set of *triples* (head, relation, tail).
The dataclasses below define the schema; Vocabulary maps strings to integer ids.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Tuple


@dataclass(frozen=True)
class Triple:
    head: str
    relation: str
    tail: str

    def validate(self) -> None:
        for name in ("head", "relation", "tail"):
            v = getattr(self, name)
            if not isinstance(v, str) or not v.strip():
                raise ValueError(f"Invalid triple field '{name}': {v!r}")


@dataclass
class Vocabulary:
    entity2id: Dict[str, int] = field(default_factory=dict)
    relation2id: Dict[str, int] = field(default_factory=dict)

    def add_triple(self, t: Triple) -> None:
        self.entity2id.setdefault(t.head, len(self.entity2id))
        self.entity2id.setdefault(t.tail, len(self.entity2id))
        self.relation2id.setdefault(t.relation, len(self.relation2id))

    @property
    def id2entity(self) -> List[str]:
        out = [""] * len(self.entity2id)
        for k, v in self.entity2id.items():
            out[v] = k
        return out

    @property
    def id2relation(self) -> List[str]:
        out = [""] * len(self.relation2id)
        for k, v in self.relation2id.items():
            out[v] = k
        return out

    @property
    def num_entities(self) -> int:
        return len(self.entity2id)

    @property
    def num_relations(self) -> int:
        return len(self.relation2id)

    def encode(self, t: Triple) -> Tuple[int, int, int]:
        return (self.entity2id[t.head], self.relation2id[t.relation], self.entity2id[t.tail])
