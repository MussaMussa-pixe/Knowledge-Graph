"""Training loop with negative sampling, validation, and checkpointing."""
import json
import random
from pathlib import Path

import numpy as np
import torch

from .data import KGData, sample_negatives
from .evaluate import evaluate
from .models import build_model


def get_device(pref: str) -> torch.device:
    if pref == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(pref)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def train(cfg: dict, data: KGData, checkpoint_path: Path, metrics_path: Path):
    tcfg, mcfg, ecfg = cfg["training"], cfg["model"], cfg["evaluation"]
    set_seed(tcfg["seed"])
    device = get_device(tcfg["device"])
    rng = np.random.default_rng(tcfg["seed"])

    model = build_model(mcfg["name"], data.vocab.num_entities, data.vocab.num_relations, mcfg).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=tcfg["learning_rate"],
                           weight_decay=tcfg.get("weight_decay", 0.0))
    train_triples = data.splits["train"]
    bs, k = tcfg["batch_size"], tcfg["negatives_per_positive"]
    best_mrr, history = -1.0, []
    print(f"Training {mcfg['name']} on {device} | {data.summary()}")

    for epoch in range(1, tcfg["epochs"] + 1):
        model.train()
        perm = rng.permutation(len(train_triples))
        total, n_batches = 0.0, 0
        for start in range(0, len(perm), bs):
            pos = train_triples[perm[start:start + bs]]
            neg = sample_negatives(pos, data.vocab.num_entities, k, rng)
            pos_t = torch.from_numpy(pos).to(device)
            neg_t = torch.from_numpy(neg).to(device)

            model.normalize()
            pos_s = model.score(pos_t[:, 0], pos_t[:, 1], pos_t[:, 2])
            neg_s = model.score(neg_t[:, :, 0], neg_t[:, :, 1], neg_t[:, :, 2])
            loss = model.loss(pos_s, neg_s)

            opt.zero_grad()
            loss.backward()
            opt.step()
            total += loss.item()
            n_batches += 1

        avg = total / max(n_batches, 1)
        entry = {"epoch": epoch, "loss": avg}
        if epoch % tcfg["eval_every"] == 0 or epoch == tcfg["epochs"]:
            m = evaluate(model, data, "valid", device, ecfg["batch_size"], ecfg["hits_at"],
                         ecfg.get("max_eval_triples"))
            entry["valid"] = m
            print(f"epoch {epoch:03d} loss {avg:.4f} | valid MRR {m['MRR']:.4f} Hits@10 {m['Hits@10']:.4f}")
            if m["MRR"] > best_mrr:
                best_mrr = m["MRR"]
                save_checkpoint(model, cfg, data, checkpoint_path)
        else:
            print(f"epoch {epoch:03d} loss {avg:.4f}")
        history.append(entry)

    metrics_path.parent.mkdir(parents=True, exist_ok=True)
    metrics_path.write_text(json.dumps({"history": history, "best_valid_mrr": best_mrr}, indent=2))
    return model


def save_checkpoint(model, cfg, data: KGData, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "state_dict": model.state_dict(),
        "config": cfg,
        "entity2id": data.vocab.entity2id,
        "relation2id": data.vocab.relation2id,
    }, path)


def load_checkpoint(path: Path, device):
    ckpt = torch.load(path, map_location=device, weights_only=False)
    cfg = ckpt["config"]
    model = build_model(cfg["model"]["name"], len(ckpt["entity2id"]), len(ckpt["relation2id"]), cfg["model"])
    model.load_state_dict(ckpt["state_dict"])
    return model.to(device).eval(), ckpt
