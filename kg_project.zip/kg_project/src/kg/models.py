"""Knowledge graph embedding models: TransE, DistMult, ComplEx.

Every model exposes:
  score(h, r, t)        -> (B,)   higher = more plausible
  score_tails(h, r)     -> (B, N) score of every entity as tail
  score_heads(r, t)     -> (B, N) score of every entity as head
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class KGEModel(nn.Module):
    def __init__(self, num_entities: int, num_relations: int, dim: int):
        super().__init__()
        self.num_entities, self.num_relations, self.dim = num_entities, num_relations, dim

    def normalize(self) -> None:
        """Hook called before each training step (used by TransE)."""

    def loss(self, pos: torch.Tensor, neg: torch.Tensor) -> torch.Tensor:
        """Logistic loss. pos: (B,), neg: (B, K)."""
        return F.softplus(-pos).mean() + F.softplus(neg).mean()


class TransE(KGEModel):
    """Bordes et al. 2013: score = -||h + r - t||."""

    def __init__(self, num_entities, num_relations, dim, margin=1.0, norm=1):
        super().__init__(num_entities, num_relations, dim)
        self.margin, self.norm = margin, norm
        self.ent = nn.Embedding(num_entities, dim)
        self.rel = nn.Embedding(num_relations, dim)
        bound = 6.0 / dim ** 0.5
        nn.init.uniform_(self.ent.weight, -bound, bound)
        nn.init.uniform_(self.rel.weight, -bound, bound)
        with torch.no_grad():
            self.rel.weight.copy_(F.normalize(self.rel.weight, dim=1))

    def normalize(self) -> None:
        with torch.no_grad():
            self.ent.weight.copy_(F.normalize(self.ent.weight, dim=1))

    def score(self, h, r, t):
        return -torch.norm(self.ent(h) + self.rel(r) - self.ent(t), p=self.norm, dim=-1)

    def score_tails(self, h, r):
        q = self.ent(h) + self.rel(r)
        return -torch.cdist(q, self.ent.weight, p=float(self.norm))

    def score_heads(self, r, t):
        q = self.ent(t) - self.rel(r)
        return -torch.cdist(q, self.ent.weight, p=float(self.norm))

    def loss(self, pos, neg):
        # Margin ranking loss: want pos > neg + margin
        return F.relu(self.margin - pos.unsqueeze(1) + neg).mean()


class DistMult(KGEModel):
    """Yang et al. 2015: score = <h, r, t> (trilinear product)."""

    def __init__(self, num_entities, num_relations, dim):
        super().__init__(num_entities, num_relations, dim)
        self.ent = nn.Embedding(num_entities, dim)
        self.rel = nn.Embedding(num_relations, dim)
        nn.init.xavier_uniform_(self.ent.weight)
        nn.init.xavier_uniform_(self.rel.weight)

    def score(self, h, r, t):
        return (self.ent(h) * self.rel(r) * self.ent(t)).sum(-1)

    def score_tails(self, h, r):
        return (self.ent(h) * self.rel(r)) @ self.ent.weight.t()

    def score_heads(self, r, t):
        return (self.rel(r) * self.ent(t)) @ self.ent.weight.t()


class ComplEx(KGEModel):
    """Trouillon et al. 2016: score = Re(<h, r, conj(t)>) with complex embeddings.

    Each embedding stores [real | imag], so the vector size is 2 * dim.
    """

    def __init__(self, num_entities, num_relations, dim):
        super().__init__(num_entities, num_relations, dim)
        self.ent = nn.Embedding(num_entities, 2 * dim)
        self.rel = nn.Embedding(num_relations, 2 * dim)
        nn.init.xavier_uniform_(self.ent.weight)
        nn.init.xavier_uniform_(self.rel.weight)

    def _split(self, x):
        return x[..., : self.dim], x[..., self.dim:]

    def score(self, h, r, t):
        hr, hi = self._split(self.ent(h))
        rr, ri = self._split(self.rel(r))
        tr, ti = self._split(self.ent(t))
        return (hr * rr * tr + hi * rr * ti + hr * ri * ti - hi * ri * tr).sum(-1)

    def score_tails(self, h, r):
        hr, hi = self._split(self.ent(h))
        rr, ri = self._split(self.rel(r))
        er, ei = self._split(self.ent.weight)
        q_re, q_im = hr * rr - hi * ri, hr * ri + hi * rr
        return q_re @ er.t() + q_im @ ei.t()

    def score_heads(self, r, t):
        rr, ri = self._split(self.rel(r))
        tr, ti = self._split(self.ent(t))
        er, ei = self._split(self.ent.weight)
        q_re, q_im = rr * tr + ri * ti, rr * ti - ri * tr
        return q_re @ er.t() + q_im @ ei.t()


def build_model(name: str, num_entities: int, num_relations: int, mcfg: dict) -> KGEModel:
    name = name.lower()
    dim = mcfg["embedding_dim"]
    if name == "transe":
        return TransE(num_entities, num_relations, dim, mcfg.get("margin", 1.0), mcfg.get("norm", 1))
    if name == "distmult":
        return DistMult(num_entities, num_relations, dim)
    if name == "complex":
        return ComplEx(num_entities, num_relations, dim)
    raise ValueError(f"Unknown model: {name}")
