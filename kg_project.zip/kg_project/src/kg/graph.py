"""Build a NetworkX graph from triples, compute statistics, export to GraphML / Neo4j CSV."""
import csv
from pathlib import Path
from typing import Dict

import networkx as nx
import numpy as np

from .schema import Vocabulary


def build_graph(triples: np.ndarray, vocab: Vocabulary) -> nx.MultiDiGraph:
    g = nx.MultiDiGraph()
    id2e, id2r = vocab.id2entity, vocab.id2relation
    for h, r, t in triples.tolist():
        g.add_edge(id2e[h], id2e[t], relation=id2r[r])
    return g


def graph_stats(g: nx.MultiDiGraph) -> Dict[str, float]:
    degrees = [d for _, d in g.degree()]
    return {
        "nodes": g.number_of_nodes(),
        "edges": g.number_of_edges(),
        "avg_degree": float(np.mean(degrees)) if degrees else 0.0,
        "max_degree": int(max(degrees)) if degrees else 0,
        "weakly_connected_components": nx.number_weakly_connected_components(g),
    }


def top_entities(g: nx.MultiDiGraph, n: int = 10):
    return sorted(g.degree(), key=lambda x: x[1], reverse=True)[:n]


def export_graphml(g: nx.MultiDiGraph, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    nx.write_graphml(g, path)


def export_neo4j_csv(triples: np.ndarray, vocab: Vocabulary, out_dir: Path) -> None:
    """Write nodes.csv and relationships.csv ready for Neo4j import."""
    out_dir.mkdir(parents=True, exist_ok=True)
    id2e, id2r = vocab.id2entity, vocab.id2relation
    with open(out_dir / "nodes.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["entityId:ID", ":LABEL"])
        for e in id2e:
            w.writerow([e, "Entity"])
    with open(out_dir / "relationships.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([":START_ID", ":END_ID", ":TYPE"])
        for h, r, t in triples.tolist():
            rel_type = "".join(c if c.isalnum() else "_" for c in id2r[r].strip("/")).upper()
            w.writerow([id2e[h], id2e[t], rel_type or "RELATED_TO"])
