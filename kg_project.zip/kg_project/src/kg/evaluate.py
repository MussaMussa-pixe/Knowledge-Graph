"""Filtered link-prediction evaluation (MRR, Hits@k)."""
from collections import defaultdict
from typing import Dict, List, Optional

import numpy as np
import torch

from .data import KGData


def build_filters(all_true):
    tails, heads = defaultdict(list), defaultdict(list)
    for h, r, t in all_true:
        tails[(h, r)].append(t)
        heads[(r, t)].append(h)
    return tails, heads


@torch.no_grad()
def evaluate(model, data: KGData, split: str, device, batch_size: int = 256,
             hits_at: List[int] = (1, 3, 10), max_triples: Optional[int] = None) -> Dict[str, float]:
    """Rank the true head and true tail against all entities, ignoring other known true answers."""
    model.eval()
    triples = data.splits[split]
    if max_triples and len(triples) > max_triples:
        triples = triples[np.random.default_rng(0).choice(len(triples), max_triples, replace=False)]
    tail_filter, head_filter = build_filters(data.all_true)
    ranks = []
    for start in range(0, len(triples), batch_size):
        batch = triples[start:start + batch_size]
        h = torch.from_numpy(batch[:, 0]).to(device)
        r = torch.from_numpy(batch[:, 1]).to(device)
        t = torch.from_numpy(batch[:, 2]).to(device)
        for mode, scores in (("tail", model.score_tails(h, r)), ("head", model.score_heads(r, t))):
            target_ids = t if mode == "tail" else h
            true = scores.gather(1, target_ids.unsqueeze(1))   # keep true score before filtering
            for i, (hh, rr, tt) in enumerate(batch.tolist()):
                others = tail_filter[(hh, rr)] if mode == "tail" else head_filter[(rr, tt)]
                scores[i, others] = float("-inf")               # remove all known true answers
            ranks.append((scores > true).sum(1) + 1)
    ranks = torch.cat(ranks).float()
    metrics = {"MR": ranks.mean().item(), "MRR": (1.0 / ranks).mean().item()}
    for k in hits_at:
        metrics[f"Hits@{k}"] = (ranks <= k).float().mean().item()
    metrics["num_ranked"] = int(len(ranks))
    return metrics
