"""Command line entry point.

Usage:
    python main.py download
    python main.py explore
    python main.py train [--model complex] [--epochs 50]
    python main.py evaluate
    python main.py predict --head /m/027rn --relation /location/country/form_of_government
"""
import argparse
import json

from src.kg.config import load_config, resolve
from src.kg.data import KGData, download_dataset
from src.kg import graph as G


def get_data(cfg) -> KGData:
    d = cfg["dataset"]
    path = download_dataset(d["base_url"], d["name"], d["files"], resolve(d["data_dir"]))
    return KGData(path)


def cmd_download(cfg, args):
    get_data(cfg)
    print("Dataset ready.")


def cmd_explore(cfg, args):
    data = get_data(cfg)
    print("Dataset summary:", json.dumps(data.summary(), indent=2))
    g = G.build_graph(data.splits["train"], data.vocab)
    print("Graph stats:", json.dumps(G.graph_stats(g), indent=2))
    print("Top-10 entities by degree:", G.top_entities(g, 10))
    p = cfg["paths"]
    G.export_graphml(g, resolve(p["graph_graphml"]))
    G.export_neo4j_csv(data.splits["train"], data.vocab, resolve(p["neo4j_dir"]))
    print(f"Exported GraphML to {p['graph_graphml']} and Neo4j CSV to {p['neo4j_dir']}/")


def cmd_train(cfg, args):
    from src.kg.train import train
    if args.model:
        cfg["model"]["name"] = args.model
    if args.epochs:
        cfg["training"]["epochs"] = args.epochs
    data = get_data(cfg)
    p = cfg["paths"]
    train(cfg, data, resolve(p["checkpoint"]), resolve(p["metrics"]))
    print("Training finished. Best model saved to", p["checkpoint"])


def cmd_evaluate(cfg, args):
    from src.kg.evaluate import evaluate
    from src.kg.train import get_device, load_checkpoint
    data = get_data(cfg)
    device = get_device(cfg["training"]["device"])
    model, _ = load_checkpoint(resolve(cfg["paths"]["checkpoint"]), device)
    e = cfg["evaluation"]
    m = evaluate(model, data, "test", device, e["batch_size"], e["hits_at"], e.get("max_eval_triples"))
    print(json.dumps(m, indent=2))


def cmd_predict(cfg, args):
    from src.kg.predict import predict_heads, predict_tails
    from src.kg.train import get_device, load_checkpoint
    device = get_device(cfg["training"]["device"])
    model, ckpt = load_checkpoint(resolve(cfg["paths"]["checkpoint"]), device)
    if args.head:
        res = predict_tails(model, ckpt, args.head, args.relation, args.top_k, device=device)
        print(f"({args.head}, {args.relation}, ?)")
    else:
        res = predict_heads(model, ckpt, args.relation, args.tail, args.top_k, device=device)
        print(f"(?, {args.relation}, {args.tail})")
    for ent, score in res:
        print(f"  {score:8.4f}  {ent}")


def main():
    parser = argparse.ArgumentParser(description="Knowledge Graph Embedding project")
    parser.add_argument("--config", default=None, help="path to config.yaml")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("download")
    sub.add_parser("explore")
    t = sub.add_parser("train")
    t.add_argument("--model", choices=["transe", "distmult", "complex"])
    t.add_argument("--epochs", type=int)
    sub.add_parser("evaluate")
    pr = sub.add_parser("predict")
    pr.add_argument("--head")
    pr.add_argument("--tail")
    pr.add_argument("--relation", required=True)
    pr.add_argument("--top-k", type=int, default=10)
    args = parser.parse_args()

    cfg = load_config(args.config) if args.config else load_config()
    {"download": cmd_download, "explore": cmd_explore, "train": cmd_train,
     "evaluate": cmd_evaluate, "predict": cmd_predict}[args.command](cfg, args)


if __name__ == "__main__":
    main()
